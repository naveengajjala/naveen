package com.niit.dao;

import java.util.List;

import com.niit.model.Blog;

public interface BlogDao {
	public void createNewBlog(Blog blog);
	public List<Blog> getBlogList(String blogUserName);
	public Blog getBlogById(int blogId);
	public Blog getBlogByName(String blogName);
	public void delete(int blogId);
	public List<Blog> getBlog();

}
