package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.UserDao;
import com.niit.model.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDao userdao;
	
	@Transactional
	public void setUserDao(UserDao userdao)
	{
		this.userdao=userdao;
	}

	public void saveOrUpdate(User user) {	
		userdao.saveOrUpdate(user);
	}

	@Transactional
	public User getUserById(int userId) {
		return userdao.getUserById(userId);
	}

	@Transactional
	public List<User> list() {
		return userdao.list();
	}

	@Transactional
	public User getUserByname(String userName) {
		return userdao.getUserByname(userName);
	}

}
