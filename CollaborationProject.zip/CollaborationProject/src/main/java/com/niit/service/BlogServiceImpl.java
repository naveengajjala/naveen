package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.niit.dao.BlogDao;
import com.niit.model.Blog;

public class BlogServiceImpl implements BlogService{
	@Autowired
	BlogDao blogdao;
	
	public void createNewBlog(Blog blog) {
		blogdao.createNewBlog(blog);
	}

	public List<Blog> getBlogList(String blogUserName) {
		return blogdao.getBlogList(blogUserName);
	}

	public Blog getBlogById(int blogiI) {
		return new Blog();
	}

	public Blog getBlogByName(String blogName) {
		return new Blog();
	}

	public List<Blog> getBlog() {
		System.out.println("i am in blog serivce");
		return blogdao.getBlog();
	}
	

}
